/*		@(#)TestSavingsAccount.java	Oct 18, 2023
 *
 */


/**
 * Class to test the SavingsAccount class.
 * 
 * @author 
 * @version 1.0.0
 */
public class TestSavingsAccount {	
	/**
	 * Test run for a Savings Account.
	 * @param args	Command line arguments that may be passed to the class at invocation time.
	 */
	public static void main(String[] args) {
		/*	create a "dummy" customer for use with the bank acccount being tested ...
		 * 			constructor()
		 * 			deposit()
		 * 		 	withDraw()
		 * 			calculateServiceCharge()
		 * 			deductServiceCharge()
		 * 			balance
		 */
		System.out.println("\n\nTesting of SavingsAccount  ******\n");
		
		Customer customer1 = new Customer("Sally Smith", "1385 woodroffe ave.");
		System.out.println("\nCreated a customer:" + customer1);
		
		BankAccount account = new SavingsAccount(customer1);
		System.out.println("Bank account owner is " + account.accountOwner());
		
		double openingBalance = account.balanceIs();
		
		double depositAmount1 = 1000.50;
		double depositAmount2 = 55.75;
		double withDrawalAmount1 = 500.75;
		double withDrawalAmount2 = 1500.00;
		
		System.out.println("depositing:" + depositAmount1 + "  balance: " + account.deposit(depositAmount1)
			+ "  EXPECTED balance of "  + (openingBalance + depositAmount1));
		
		System.out.println("depositing:" + depositAmount2 + "  balance: " + account.deposit(depositAmount2)
			+ "  EXPECTED balance of " + ( depositAmount1 + depositAmount2));

		openingBalance = account.balanceIs();
		System.out.println("with drawing :" + withDrawalAmount1 + "  balance: " + account.withDraw(withDrawalAmount1)
			+ "  EXPECTED balance of " + (openingBalance - withDrawalAmount1));

		System.out.println("with drawing :" + withDrawalAmount2 + "  balance: " + account.withDraw(withDrawalAmount2)
			+ " EXPECTED RESULT: Not enough balance");
		
		double serviceCharge =  account.calculateServiceCharge();
		openingBalance = account.balanceIs();
		System.out.println("Deducting a service charge of " + serviceCharge
				+ "  Account balance is " + account.deductServiceCharge(serviceCharge)
				+ "  EXPECTED RESULT: " + (openingBalance - 5.0));
		System.out.println("\n\nTesting of SavingsAccount class complete ******");
		System.exit(0);
		// Create the first customer
		Customer customer11 = new Customer("John Doe", "123 Main St.");
		System.out.println("\nCreated a customer:" + customer11);
		
		// Create a SavingsAccount for the first customer
		BankAccount savingsAccount1 = new SavingsAccount(customer11);
		System.out.println("Bank account owner is " + savingsAccount1.accountOwner());
		double openingBalance1 = savingsAccount1.balanceIs();
		
		// Test deposit functionality for the first customer's SavingsAccount
		double depositAmount11 = 500.25;
		System.out.println("Depositing:" + depositAmount11 + "  Balance: " + savingsAccount1.deposit(depositAmount11)
			+ "  EXPECTED balance of "  + (openingBalance1 + depositAmount11));

		// Test withdrawal functionality for the first customer's SavingsAccount
		openingBalance1 = savingsAccount1.balanceIs();
		double withDrawalAmount11 = 200.50;
		System.out.println("Withdrawing:" + withDrawalAmount11 + "  Balance: " + savingsAccount1.withDraw(withDrawalAmount11)
			+ "  EXPECTED balance of " + (openingBalance1 - withDrawalAmount11));

		// Test calculateServiceCharge for the first customer's SavingsAccount
		double serviceCharge1 = savingsAccount1.calculateServiceCharge();
		openingBalance1 = savingsAccount1.balanceIs();
		System.out.println("Service Charge for the first account: " + serviceCharge1
				+ "  Account balance is " + savingsAccount1.deductServiceCharge(serviceCharge1)
				+ "  EXPECTED RESULT: " + (openingBalance1 - serviceCharge1));

		// Create a second customer
		Customer customer2 = new Customer("Jane Smith", "456 Oak St.");
		System.out.println("\nCreated another customer:" + customer2);

		// Create a SavingsAccount for the second customer
		BankAccount savingsAccount2 = new SavingsAccount(customer2);
		System.out.println("Bank account owner is " + savingsAccount2.accountOwner());
		double openingBalance2 = savingsAccount2.balanceIs();

		// Test deposit functionality for the second customer's SavingsAccount
		double depositAmount21 = 1000.75;
		System.out.println("Depositing:" + depositAmount21 + "  Balance: " + savingsAccount2.deposit(depositAmount21)
			+ "  EXPECTED balance of "  + (openingBalance2 + depositAmount21));

		// Test withdrawal functionality for the second customer's SavingsAccount
		openingBalance2 = savingsAccount2.balanceIs();
		double withDrawalAmount21 = 500.00;
		System.out.println("Withdrawing:" + withDrawalAmount21 + "  Balance: " + savingsAccount2.withDraw(withDrawalAmount21)
			+ "  EXPECTED balance of " + (openingBalance2 - withDrawalAmount21));

		// Test calculateServiceCharge for the second customer's SavingsAccount
		double serviceCharge2 = savingsAccount2.calculateServiceCharge();
		openingBalance2 = savingsAccount2.balanceIs();
		System.out.println("Service Charge for the second account: " + serviceCharge2
				+ "  Account balance is " + savingsAccount2.deductServiceCharge(serviceCharge2)
				+ "  EXPECTED RESULT: " + (openingBalance2 - serviceCharge2));

		System.out.println("\n\nTesting of SavingsAccount class complete ******");
		System.exit(0);

	}
}
