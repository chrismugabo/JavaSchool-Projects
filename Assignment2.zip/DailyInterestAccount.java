/*		@(#)DailyInterestAccount.java	Oct 18, 2023
 *
 */


/**
 * TODO: Document me
 * This class represents a daily interest bank account.
 * DailyInterestAccount inherits from the BankAccount class.
 * It provides specific functionality related to service charge calculation.
 * @author 
 * @version 1.0.0
 */
public class DailyInterestAccount extends BankAccount	{

	/**
	 * Initialize the bank account object by giving the parent (BankAccount)
	 * the customer object reference.
	 */
	public DailyInterestAccount(Customer customer)	{
		super(customer);
	}

	
	/**
	 * The service charge calculation for a daily interest account is 1.5% if the balance is over $1000.00
	 *	else if balance is under $1000.00 2%
	 *	@return	The calculated service charge for this account type.
	 */
	public double calculateServiceCharge()	{
		/*	Implement the service charge.  You may access the BankAccount.balance field directly as it is now a "protected" member		*/
		double balance = balanceIs();
		double serviceCharge = balance * .02;
		if (balance > 1000)	{
			serviceCharge = balance * .015;
		}
		
		return serviceCharge;
	}

}
