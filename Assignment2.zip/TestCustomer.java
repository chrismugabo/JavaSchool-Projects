/*		@(#)TestCustomer.java	Oct 18, 2023
 *
 */


/**
 * Test class for the Customer class
 * 
 * @author 
 * @version 1.0.0
 */
public class TestCustomer {
	
	
	/**
	 * Begin testing the customer class here.
	 * @param args	Command line arguments that may be passed to the class at invocation time.
	 */
	public static void main(String[] args) {
		
		/*	Create a customer object
		 * 		Test each constructor (validate that the instance members are set correctly)
		 * 		Test methods in the customer class
		 * 
		 * 			getName()
		 * 			getAddress()
		 * 			setName()
		 * 			setAddress()
		 * 			addPhoneNumber()
		 * 			phoneNumber()
		 * 			addAccount()
		 * 			bankAccounts()
		 * 
		 * 	Simple sample below
		 * 
		 * Ensure all other test classes are complete and correct.
		 */


		Customer customer1 = new Customer("Sally Smith", "1385 woodroffe ave.");	
		System.out.println("Customer1:toString():" + customer1);
		customer1.setName("Sally Smeert");
		System.out.println("Customer1:getName():" + customer1.getName());

		/* Test each constructor (validate that the instance members are set correctly) */
		System.out.println("Customer1: getName(): " + customer1.getName());  // Expected: Sally Smith
		System.out.println("Customer1: getAddress(): " + customer1.getAddress());  // Expected: 1385 Woodroffe Ave.

		/* Test methods in the Customer class */
		customer1.setName("Sally Smeert");
		System.out.println("Customer1: setName(): " + customer1.getName());  // Expected: Sally Smeert

		customer1.setAddress("123 Main St.");
		System.out.println("Customer1: setAddress(): " + customer1.getAddress());  // Expected: 123 Main St.

		/* Add phone numbers and retrieve them */
		customer1.addPhoneNumber(Customer.HOME, "123-456-7890");
		customer1.addPhoneNumber(Customer.WORK, "456-789-0123");
		customer1.addPhoneNumber(Customer.CELL, "789-012-3456");

		System.out.println("Customer1: phoneNumbers(): " + String.join(", ", customer1.phoneNumbers()));
		// Expected: 123-456-7890 - HOME, 456-789-0123 - WORK, 789-012-3456 - CELL

		System.out.println("Customer1: phoneNumber(HOME): " + customer1.phoneNumber(Customer.HOME));
		// Expected: 123-456-7890

		/* Add a bank account and retrieve them */
		BankAccount account1 = new ChequingAccount(customer1);
		customer1.addBankAccount(account1);

		BankAccount account2 = new SavingsAccount(customer1);
		customer1.addBankAccount(account2);

		System.out.println("Customer1: bankAccounts(): " + Arrays.toString(customer1.bankAccounts()));
		
		
		

	}
}
