/*		@(#)SavingsAccount.java	Oct 18, 2023
 *
 */

/**
 *	A savings account is a specific type of bank account.
 *	At this point the savings account has a unique service charge calculation.
 */
public class SavingsAccount extends BankAccount		{
	
	/**
	 * 
	 */
	public SavingsAccount(Customer customer)	{
		super(customer);
	}

	/**
	 * 	Service charges for a savings account is a monthly amount of $5.00.
	 * @return	The calculated service charge.
	 */
	public double calculateServiceCharge()	{
		return 5.0;
	}
	
	
}
