/*		@(#)BankAccount.java	Oct 18, 2023
 *
 */


/**
 *	Bank account objects form the foundation for all specific types of bank accocunt.
 *	A bank account can never exist on its own, it must always be an objetc of a specific
 *	type of  bank account (therefore it should be "abstract" to reflect the business constraint).
 * 
 * @author 
 * @version 1.0.0
 */
public  abstract class BankAccount {
	
	/*	CONSTRUCTORS	----------------------------------------------------------------	*/
	
	/**
	 *	Create a bank account that is owned by a specific customer.
	 *@param	customer	The customer that owns this bank account.
	 */
	public BankAccount(Customer customer)	{
		/* TODO: set the instance variable customer to the argument value customer		*/
		 this.customer = customer;  
	}

	/*	ACCESSORS		----------------------------------------------------------------	*/
	 
	  public double balanceIs1() {
	        return balance;
	    }

	/*	MUTATORS			----------------------------------------------------------------	*/
	public void setBalance(double balance) {
        this.balance = balance;
    }
	
	
	/*	NORMAL BEHAVIOR	--------------------------------------------------------------	*/
	
	/**
	 * Perform a withdrawal from the bank account.  Validate there is enough money in the account
	 * to cover the withdrawal.
	 * @param wiDrawAmount  The amount to withdraw.
	 * @return	Return the new balance
	 */
	public double withDraw(double withDrawAmount)	{
		/*
		 * Validate there is enough month in the account to cover the withdrawal.
		 */
		if (withDrawAmount > balance)	{
			System.out.println("Not enough balance, cannot make withdrawl of " + withDrawAmount);
		} else	{
			balance -= withDrawAmount;
		}
		
		return balance;
	}
	
	
	/**
	 * Deposit cash or cheques into a customer's bank account.  The deposit must be a positive amount.
	 * @param withdrawalAmount	The amount of currency being added to a customers account.
	 * @return	The new balance after the deposit.
	 */
	public double deposit(double depositAmount)	{
		/*	Add the deposit amount to the bank account's balance and return the new balance			*/
		return balance += depositAmount;
	}

	/**
	 * Get the account owners name for this account
	 * @return	first and last name of the bank account owner.
	 */
	public String accountOwner()	{
		return (customer != null) ? customer.getName() : "";
	}

	/**
	 * Service charge method with no implementation as there is no default way to calculate a service charge.
	 * The service charge calculation is deferred to a child class of BankAccount.
	 * @return	The amount of the service charge.
	 */
	public abstract double calculateServiceCharge();
	

	/**
	 * deduct the service charge from the account balance for this bank account.
	 * @param	serviceCharge	The service charge amount to deduct from this account.
	 * @return	The new balance for this account after deducting the service charge.
	 */
	public double deductServiceCharge(double serviceCharge)	{
		return balance -= serviceCharge;
	}
	
	
	/*	TODO: Document and add the method to obtain the account balance for this account.
	 * See the UML diagram for the method name, return type and visibility.
	 */
	
	public double balanceIs()	{
		return balance;
	}

	
	/*	HELPER METHODS		--------------------------------------------------------------	*/
	
	/*	ATTRIBUTES	------------------------------------------------------------------	*/
	/** The customer that owns this bank account.										*/
	private Customer customer;

	/** The current balance for this bank account.										*/
	private double balance;

}
