/*		@(#)ChequingAccount.java	Oct 18, 2023
 *
 */

/**
 * TODO: Document me (the Class) Represents a Chequing Account that extends a Bank Account.
 */
public class ChequingAccount extends BankAccount	 {
	/**
	 * TODO: The customer associated with the account
	 * @param customer
	 */
	public ChequingAccount(Customer customer)	{
		super(customer);
	}
	
	/**
	 * 	Service charges for a chequing account is a monthly amount of $10.00.
	 * @return	The calculated service charge for this account type.
	 */
	public double calculateServiceCharge()	{
		/*	Implement the service charge calculation here for a ChequingAccount object				 */
		return 10.0;
	}

}

