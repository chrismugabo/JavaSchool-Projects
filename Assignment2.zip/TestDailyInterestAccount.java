/*		@(#)TestSavingsAccount.java	Oct 18, 2023
 *
 */


/**
 * Class to test the SavingsAccount class.
 * 
 * @author 
 * @version 1.0.0
 */
public class TestDailyInterestAccount {
	
	
	/**
	 * TODO:	Document me
	 * @param args	Command line arguments that may be passed to the class at invocation time.
	 */
	public static void main(String[] args) {
		/*	create a "dummy" customer and test...
		 * 			construtor()
		 * 			deposit()
		 * 		 	withDraw()
		 * 			calculateServiceCharge()
		 * 			balance
		 */
		System.out.println("\n\nTesting of DailyInterestAccount class  ******\n");

		Customer customer1 = new Customer("Sally Smith", "1385 woodroffe ave.");
		System.out.println("\nCreated a cusotmer:" + customer1);
		
		BankAccount account = new DailyInterestAccount(customer1);
		System.out.println("Bank account owner is " + account.accountOwner());
		double openingBalance = account.balanceIs();
		
		double depositAmount1 = 1000.50;
		double depositAmount2 = 55.75;
		double withDrawalAmount1 = 500.75;
		double withDrawalAmount2 = 1500.00;
		
		System.out.println("depositing:" + depositAmount1 + "  balance: " + account.deposit(depositAmount1)
			+ "  EXPECTED balance of "  + (openingBalance + depositAmount1));

		
		System.out.println("depositing:" + depositAmount2 + "  balance: " + account.deposit(depositAmount2)
			+ "  EXPECTED balance of " + ( depositAmount1 + depositAmount2));

		openingBalance = account.balanceIs();
		System.out.println("with drawing :" + withDrawalAmount1 + "  balance: " + account.withDraw(withDrawalAmount1)
			+ "  EXPECTED balance of " + (openingBalance - withDrawalAmount1));

		System.out.println("with drawing :" + withDrawalAmount2 + "  balance: " + account.withDraw(withDrawalAmount2)
			+ " EXPECTED RESULT: Not enough balance");
		
		double serviceCharge = account.calculateServiceCharge();
		openingBalance = account.balanceIs();
		System.out.println("Deducting a service charge of " + serviceCharge
				+ "  Account balance is " + account.deductServiceCharge(serviceCharge)
				+ "  EXPECTED RESULT: " + (openingBalance - 11.11));
		System.out.println("\n\nTesting of DailyInterestAccount class complete ******");
		System.exit(0);
		
	}
}
