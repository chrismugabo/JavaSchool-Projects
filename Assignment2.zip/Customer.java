/*		@(#)Customer.java	Oct 18, 2023
 *
 */

/*
 * 	Definition of a method
 *
 * 	public void setName(String name) {	this.name = name; }
 *
 * 	visibility return-type	methodName (  comma separated argument-list )	{   method body or implementation	}
 *		- on the class diagram indicates the method is "private"
 *		+ on the class diagram, indicates the method is "public"
 *
 * 														Datatype argumentName
 * 	public		void			main				String	name									this.name = name
 *
 *		public		String		getName()	{ return "this is a name";		}
 *
 *
 *		ALL statements are terminated with a ";" semi-colon
 *
 *		Attributes declarations (variables with class scope)
 *		visibility	data-type	variable-name
 *
 *		private		String		name;
 *
 *		Local scope variables (inside methods)
 *		data-type	name
 *
 *		Integer		counter
 *
 *
 */

/**
 * This class represents a bank customer. Customers can open bank accounts have
 * particulars like name and address, telephone number.
 * 
 * @author	  
 * @version 1.0.0
 */
public class Customer {
	public static final String HOME = "H";
	public static final String WORK = "W";
	public static final String CELL = "C";

	/*
	 * CONSTRUCTORS
	 * ----------------------------------------------------------------
	 */

	/**
	 * Overloaded Constructor to create a customer with a name and address
	 * 
	 * @param  The name of the customer.
	 *            
	 * @param address
	 *            The address of the customer.
	 */
	public Customer(String name, String address) {
		/*
		 * "this" and the "." operator (referred to as the scope resolution
		 * operator) is used to resolve the ambiguity between the variable named
		 * "name" in the argument list and the class scope variable (instance
		 * variable) named name for the class
		 */
		this.name = name;
		this.address = address;
	}

	/*
	 * ACCESSORS ----------------------------------------------------------------
	 */
	public String getName() 		{	return name;	}
	public String getAddress()		{	return address;	}


	/*
	 * MUTATORS ----------------------------------------------------------------
	 */
	public void setName(String name)					{	this.name = name;				}
	public void setAddress(String address)				{	this.address = address;			}
	

	/*
	 * NORMAL BEHAVIOR
	 * --------------------------------------------------------------
	 */
	/**
	 * Override the method toString() from class Object
	 */
	public String toString() {
		return "[name=" + name + ",address=" + address + "]";
	}
	
	/**
	 * TODO:Add a phone number for the customer.
	 * @param type  The type of the phone number (HOME, WORK, CELL).
	 * @param phoneNumber The phone number to be added.
	 */
	public void addPhoneNumber(String type, String phoneNumber)	{
		/*	TODO:
		 * 		Add the code here to insert the phone type and phone number in their appropriates arrays.
		 * 		if the array is full with phone numbers display an error message using System.out.println()
		 */
		for (int i = 0; i < phoneNumbers.length; i++) {
            if (phoneNumbers[i] == null) {
                phoneNumbers[i] = phoneNumber;
                phoneNumberTypes[i] = type;
                return;
            }
		}
		System.out.println("Error: Phone number array is full. Cannot add more numbers.");
	}
	
	/**
	 * Find a particular type of phone number.
	 * @param	type
	 * @return	The phone number that matches the type else return "Phone Number Not Found"	
	 */
	public String phoneNumber(String type)	{
		/* TODO: add the code to get a particular type of phone number
		 * Hint, you must iterate thru the collection (array) to obtain a match on the "type" and
		 * return the phone number that represents the particular type
		 * 
		 */
		 for (int i = 0; i < phoneNumberTypes.length; i++) {
	            if (phoneNumberTypes[i] != null && phoneNumberTypes[i].equals(type)) {
	                return phoneNumbers[i];
	            }
		 }
		 return "Phone Number Not Found";
	}
	
	
	/**
	 *	Open a bank account for this customer.
	 *	This customer should be the owner of the account.
	 * 
	 * @return	True if successfully added else false
	 */
	public void addBankAccount(BankAccount account) {

		BankAccount[] myAccounts;
			/*	TODO: add the code here to add a bank account to the array of bank accounts.
		 * Be sure to keep track of the current number of bank accounts for this customer.
		 */
	        if (currentNumberOfAccounts < myAccounts.length) {
	            myAccounts[currentNumberOfAccounts] = account;
	            currentNumberOfAccounts++;
	        } else {
	            System.out.println("Error: Maximum number of bank accounts reached for this customer.");
	        }
	    }
	


	/**
	 * Provide the caller with the array of phone numbers with types.
	 * @return an array of phone numbers including the expanded type.
	 */
	public String[] phoneNumbers()	{
		String numbers[] = new String[3];

		for (int idx = 0; idx < phoneNumbers.length; idx++)	{
			if (phoneNumbers[idx] != null)	{
				switch (phoneNumberTypes[idx])	{
				case HOME:
					numbers[idx] = phoneNumbers[idx] + " - HOME";
					break;
				case WORK:
					numbers[idx] = phoneNumbers[idx] + " - WORK";
					break;
				case CELL:
					numbers[idx] = phoneNumbers[idx] + " - CELL";
					break;
				default:
					break;
				}
			}
			
		}

		return numbers;
	}


	/**
	 * Provide the caller with a copy of the array of bank accounts.
	 * @return
	 */
	public BankAccount[]	bankAccounts()	{
		return myAccounts;	
	}

	
	
	/*
	 * HELPER METHODS
	 * --------------------------------------------------------------
	 * 
	 */

	/*
	 * ATTRIBUTES
	 * ------------------------------------------------------------------
	 */

	/* CLASS SCOPE VARIABLES or INSTANCE VARIABLES */
	/**
	 * The full name of a customer, first middle and last not including a salutation
	 */
	private String name;

	/**
	 * The full address for a customer including street, city,province, country
	 */
	private String address;

	/** Collection of phone numbers.																			*/
	private String[] phoneNumbers = new String[3];

	/** Collection of phone number types.																		*/
	private String[] phoneNumberTypes = new String[3];
	
	private BankAccount[] myAccounts = new BankAccount[10]; 

	/** Lets keep track of the current number of bank accounts for this customer.  Increment this value
	 * each time a new account is added, decrement the value when an account is removed.
	 */
	private int currentNumberOfAccounts;
}